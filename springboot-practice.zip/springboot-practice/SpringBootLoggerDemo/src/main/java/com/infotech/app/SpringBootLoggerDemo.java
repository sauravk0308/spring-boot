package com.infotech.app;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@SpringBootApplication
public class SpringBootLoggerDemo{

	private static final Logger logger = LoggerFactory.getLogger(SpringBootLoggerDemo.class);
	public static void main(String[] args) {
		SpringApplication.run(SpringBootLoggerDemo.class, args);
		
		logger.error("Message logged at error level");
		logger.warn("Message logged at warn level");
		logger.info("Message logged at info level");
		logger.debug("Message logged at debug level");
	}
	@RequestMapping("/")
	public String welcom() {
		return "Hello World";
	}
}
