package com.infotech.peoplemanagement.app.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.infotech.peoplemanagement.app.entities.Person;

public interface PeopleManagementDao extends CrudRepository<Person, Integer>{
	
	@Query("Select p from Person p where p.firstName=:firstName or p.lastName=:lastName")
	List<Person> findByLastNameOrFirstName(@Param("lastName")String lastName, @Param("firstName")String firstName);
}
