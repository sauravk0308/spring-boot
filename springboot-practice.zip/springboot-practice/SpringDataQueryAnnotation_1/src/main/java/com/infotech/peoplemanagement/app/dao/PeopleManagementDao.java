package com.infotech.peoplemanagement.app.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.infotech.peoplemanagement.app.entities.Person;

public interface PeopleManagementDao extends CrudRepository<Person, Integer>{
	@Query(value="Select p From Person p where p.lastName=?1")
	List<Person> findByLastName(String lastName);
	@Query(value="Select p From Person p where p.lastName=?1 AND p.email=?2")
	List<Person> findByFirstNameAndEmail(String firstName, String email);
}
