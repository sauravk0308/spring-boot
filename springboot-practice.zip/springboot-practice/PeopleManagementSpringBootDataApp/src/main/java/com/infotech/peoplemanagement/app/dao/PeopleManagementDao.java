package com.infotech.peoplemanagement.app.dao;

import org.springframework.data.repository.CrudRepository;

import com.infotech.peoplemanagement.app.entities.Person;

public interface PeopleManagementDao extends CrudRepository<Person, Integer>{

}
