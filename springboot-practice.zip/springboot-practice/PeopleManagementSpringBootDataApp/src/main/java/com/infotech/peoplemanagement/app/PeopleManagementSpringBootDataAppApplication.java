package com.infotech.peoplemanagement.app;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.infotech.peoplemanagement.app.entities.Person;
import com.infotech.peoplemanagement.app.service.PeopleManagementService;

@SpringBootApplication
public class PeopleManagementSpringBootDataAppApplication implements CommandLineRunner{

	@Autowired
	private PeopleManagementService peopleManagementService;
	
	public static void main(String[] args) {
		SpringApplication.run(PeopleManagementSpringBootDataAppApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		createPerson();
	}
	public void createPerson() {
		Person personObj = new Person("Saurav", "kumar", "saurav@mail.com", new Date());
		Person person = peopleManagementService.createPerson(personObj);
		System.out.println("person "+person);
	}
}
